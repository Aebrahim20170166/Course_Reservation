<?php
include 'Assets/navbar.php';
?>


<div class="about">
    <div class="container">
        <div class="row">
            <div class="col-md-6 image">
                <img src="images/img2.jpg" class="card-img-top" alt="...">
            </div>
            <div class="col-md-6">
                <h4>Title</h4>
                <p>
                    Here you can use rows and columns to organize your footer content.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Here you can use rows and columns to organize your footer content.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Here you can use rows and columns to organize your footer content.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Here you can use rows and columns to organize your footer content.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                </p>
            </div>
        </div>
    </div>
</div>



<?php
include 'Assets/footer.php';
?>
